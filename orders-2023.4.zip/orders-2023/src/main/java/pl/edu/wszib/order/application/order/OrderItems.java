package pl.edu.wszib.order.application.order;

import java.util.Set;

public class OrderItems {
    private final Set<OrderItem> items;



}
