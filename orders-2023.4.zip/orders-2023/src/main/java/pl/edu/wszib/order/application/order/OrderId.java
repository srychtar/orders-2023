package pl.edu.wszib.order.application.order;

public class OrderId {
    private final String id;
}
