package pl.edu.wszib.order;

public class OrderMain {
    public static void main(final String[] args) {

    }
}
