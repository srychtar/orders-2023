package pl.edu.wszib.order.application.product;

public class ProductId {
    private final String id;
}
