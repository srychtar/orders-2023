package pl.edu.wszib.order.application.order;

import pl.edu.wszib.order.application.product.Product;

import java.math.BigDecimal;

public class OrderItem {

    private final Product product;
    private final Integer quantity;
    private final BigDecimal amount;
}
