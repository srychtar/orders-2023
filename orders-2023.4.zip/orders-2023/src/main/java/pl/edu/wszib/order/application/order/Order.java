package pl.edu.wszib.order.application.order;

import java.math.BigDecimal;

public class Order {
    private final OrderId id;
    private final OrderState state;
    private final OrderItems items;
    private final BigDecimal amount;



}
