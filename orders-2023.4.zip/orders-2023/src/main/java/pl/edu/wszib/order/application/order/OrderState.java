package pl.edu.wszib.order.application.order;

public enum OrderState {
    CREATED,
    FINISHED,
    ABANDONED,
    ;
}
